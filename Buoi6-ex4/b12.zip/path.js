
module.exports = {
    folder_app       : 'app',
    folder_configs   : 'configs',
    folder_helpers   : 'helpers',
    folder_routers   : 'routes',
    folder_schemas   : 'schemas',
    folder_models    : 'models',
    folder_validates    : 'validates',
    folder_middleware   : 'middleware',
    folder_views        : 'vviews',
    folder_module_admin : 'admin69',
    folder_module_blog  : 'blog',
    folder_public       : 'public',
    folder_uploads      : 'uploads'
};