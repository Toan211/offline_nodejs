<script src="js/jquery/jquery.min.js"></script>
<script src="js/jquery-ui/jquery-ui.min.js"></script>
<script src="js/popper/umd/popper.min.js"></script>
<script src="js/notifyjs/notify.min.js"></script>
<script src="js/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="js/sweetalert2/sweetalert2.min.js"></script>
<script src="js/adminlte.js"></script>
