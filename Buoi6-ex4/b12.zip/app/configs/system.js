
module.exports = {
    prefixAdmin: 'adminCCC',
    format_long_time: 'DD-MM-YYYY',
    status_value: [
        {id: 'novalue', name: 'Choose Status'},
		{id: 'active', name: 'Active'},
		{id: 'inactive', name: 'InActive'},
    ],
    groupacp_value: [
        {id: 'novalue', name: 'Choose Group ACP'},
		{id: 'yes', name: 'Yes'},
		{id: 'no', name: 'No'},
    ]
};