
module.exports = {
    port: 6969
}
