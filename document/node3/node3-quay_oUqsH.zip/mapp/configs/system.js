
module.exports = {
    prefixAdmin: 'admin123',    // hdsdnsk
    prefixBlog: 'blog123',
    prefixChat: '',
    env: 'dev', // production dev
    format_long_time: 'DD-MM-YYYY',
    format_time_frontend: 'DD-MM-YYYY',
    format_time_chat: 'HH:mm DD-MM-YYYY'
};