
module.exports = {
    username: 'hailan',
    password: '123456',
    database: 'training_nodejs',
    col_items: 'items',
    col_groups: 'groups',
    col_users: 'users',
    col_category: 'categories',
    col_article: 'article',
    col_chats: 'chats',
    col_chats_room: 'chats-rooms',
    col_rooms: 'rooms'
};